//Cindy Natsuki Yoshita RA:19.00633-0
//Thiago Akio Kanada Tanaka Ra:19.01726-0

package maua.cindy.thiago;

import maua.cindy.thiago.sistema.Sistema;

// Inicialização do sistema
public class Main {

    public static void main(String[] args) throws Exception {
       Sistema ss = new Sistema();
        ss.start();
    }
}
