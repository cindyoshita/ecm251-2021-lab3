package maua.cindy.thiago;

import maua.cindy.thiago.sistema.Sistema;
import maua.cindy.thiago.sistema.metodos.MudarHorario;

public class Main {

    public static void main(String[] args) throws Exception {
       Sistema ss = new Sistema();
        ss.start();
    }
}
