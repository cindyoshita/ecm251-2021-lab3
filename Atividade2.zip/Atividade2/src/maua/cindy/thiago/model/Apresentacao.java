package maua.cindy.thiago.model;

/**
 * Interface comprometendo a classe que implementa-la para ter o metodo apresentar
 */
public interface Apresentacao {
    public abstract void apresentar();
}
