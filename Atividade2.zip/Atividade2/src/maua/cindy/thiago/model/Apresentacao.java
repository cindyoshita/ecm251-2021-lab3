package maua.cindy.thiago.model;

public interface Apresentacao {
}
