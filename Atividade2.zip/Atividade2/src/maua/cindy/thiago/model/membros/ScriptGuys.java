package maua.cindy.thiago.model.membros;

import maua.cindy.thiago.model.Membro;

public class ScriptGuys extends Membro {
    @Override
    public void mensagemRegular() {
        System.out.println("Prazer em ajudar novos amigos de código!");;
    }

    @Override
    public void mensagemExtra() {
        System.out.println("“QU3Ro_S3us_r3curs0s.py");;
    }
}
