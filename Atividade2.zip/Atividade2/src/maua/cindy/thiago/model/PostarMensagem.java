package maua.cindy.thiago.model;

public interface PostarMensagem {
    public abstract void mensagemRegular();
    public abstract void mensagemExtra();
}
