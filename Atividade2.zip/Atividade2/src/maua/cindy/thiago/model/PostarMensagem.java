package maua.cindy.thiago.model;

/**
 * Interface comprometendo a classe que implementa-la para ter os metodos mensagemRegular e mensagemExtra
 */
public interface PostarMensagem {
    public abstract void mensagemRegular();
    public abstract void mensagemExtra();
}
