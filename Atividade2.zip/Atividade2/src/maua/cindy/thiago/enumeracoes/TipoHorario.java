package maua.cindy.thiago.enumeracoes;

/**
 * Retorna os tipos de horário existentes
 */
public enum TipoHorario {
    REGULAR, EXTRA;
}
