package maua.cindy.thiago.enumeracoes;

public enum TipoHorario {
    REGULAR, EXTRA;
}
