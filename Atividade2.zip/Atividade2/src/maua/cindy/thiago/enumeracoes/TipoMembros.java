package maua.cindy.thiago.enumeracoes;

public enum TipoMembros {
    MOBILEMEMBERS, HEAVYLIFTERS, SCRIPTGUYS, BIGBROTHERS;
}
