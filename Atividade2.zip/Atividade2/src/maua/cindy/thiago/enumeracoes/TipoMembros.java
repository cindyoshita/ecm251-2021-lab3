package maua.cindy.thiago.enumeracoes;

/**
 * Retorna os tipos de membro existentes
 */
public enum TipoMembros {
    MOBILEMEMBERS, HEAVYLIFTERS, SCRIPTGUYS, BIGBROTHERS;
}
